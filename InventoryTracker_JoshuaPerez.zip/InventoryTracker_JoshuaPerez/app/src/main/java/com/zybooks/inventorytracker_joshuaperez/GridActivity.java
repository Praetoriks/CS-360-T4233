package com.zybooks.inventorytracker_joshuaperez;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class GridActivity extends AppCompatActivity {

    // Declares the necessary components
    RecyclerView recycler_view;
    FloatingActionButton floatingAddButton;
    FloatingActionButton floatingNotificationButton;

    DBInventory myDB;
    ArrayList<String> item_id, item_name, item_amount;
    CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        floatingNotificationButton = findViewById(R.id.floatingNotificationButton);
        // On click for notification button using lambda operation
        floatingNotificationButton.setOnClickListener(view -> {
            Intent intent1 = new Intent(GridActivity.this, NotificationActivity.class);
            startActivity(intent1);
        });

        recycler_view = findViewById(R.id.recycler_view);
        floatingAddButton = findViewById(R.id.floatingAddButton);
        // On click for add item button using lambda operation
        floatingAddButton.setOnClickListener(view -> {
            Intent intent = new Intent(GridActivity.this, AddActivity.class);
            startActivity(intent);
        });

        // Set up the data for the array that will be used
        myDB = new DBInventory (GridActivity.this);
        item_id = new ArrayList<>();
        item_name = new ArrayList<>();
        item_amount = new ArrayList<>();

        storeDataInArrays();

        customAdapter = new CustomAdapter(GridActivity.this,this, item_id, item_name,
                item_amount);
        recycler_view.setAdapter(customAdapter);
        recycler_view.setLayoutManager(new LinearLayoutManager(GridActivity.this));

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1){
            recreate();
        }
    }

    void storeDataInArrays(){
        Cursor cursor = myDB.readAllData();
        if(cursor.getCount() == 0) {
            Toast.makeText(this, "No Data", Toast.LENGTH_SHORT).show();
        }else{
            while (cursor.moveToNext()){
                item_id.add(cursor.getString(0));
                item_name.add(cursor.getString(1));
                item_amount.add(cursor.getString(2));
            }
        }
    }
}
package com.zybooks.inventorytracker_joshuaperez;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterAccountActivity extends AppCompatActivity {

    // Declarations
    EditText username, password, password2;
    Button registeraccountbtn;
    Button returntologinbtn;
    DBLogin myDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_account);

        // Here we designate which variables are tied to the appropriate components
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        password2 = (EditText) findViewById(R.id.password2);

        registeraccountbtn = (Button) findViewById(R.id.register_account_button);
        returntologinbtn = (Button) findViewById(R.id.return_to_login);

        myDB = new DBLogin(this);

        // Contains registration logic
        registeraccountbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String pass2 = password2.getText().toString();
                if (user.equals("") || pass.equals("") || pass2.equals("")) {
                    Toast.makeText(RegisterAccountActivity.this, "Fill all the fields", Toast.LENGTH_SHORT).show();
                } else {
                    if (pass.equals(pass2)) {
                        Boolean userCheckResult = myDB.checkusername(user);
                        if (userCheckResult == false) {
                            Boolean regResult = myDB.insertData(user, pass);
                            if (regResult == true) {
                                Toast.makeText(RegisterAccountActivity.this, "Registration Successful. \n Return to Login Page", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(RegisterAccountActivity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(RegisterAccountActivity.this, "User already exists", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(RegisterAccountActivity.this, "Password not matching.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // Logic for returning back to the login screen
        returntologinbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openLoginActivity();
            }
        });
    }

    public void openLoginActivity() {
        Intent int1 = new Intent(this, LoginActivity.class);
        startActivity(int1);
    }
}


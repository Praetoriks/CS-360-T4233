package com.zybooks.inventorytracker_joshuaperez;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class AddActivity extends AppCompatActivity {

    // Declarations
    EditText item_name_input, item_amount_input;
    Button add_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        // Assigning the information inputted into the xml into a variable we can use
        item_name_input = findViewById(R.id.item_name_input);
        item_amount_input = findViewById(R.id.item_amount_input);
        add_button = findViewById(R.id.addbtn);
        // On click for add button using lambda operation
        add_button.setOnClickListener(view -> {
            // Get item information and add it to the DB so it can be displayed by Adapter
            DBInventory myDB = new DBInventory(AddActivity.this);
            myDB.addItem(item_name_input.getText().toString().trim(),
                    Integer.valueOf(item_amount_input.getText().toString().trim()));
        });
    }
}
package com.zybooks.inventorytracker_joshuaperez;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    // Declarations
    EditText username, password;
    Button signinbtn;
    Button createacctbtn;
    DBLogin myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Here we designate which variables are tied to the appropriate components
        username = findViewById(R.id.usernameLogin);
        password = findViewById(R.id.passwordLogin);
        signinbtn = findViewById(R.id.signinbtn);
        createacctbtn = findViewById(R.id.createacctbtn);

        myDB = new DBLogin(this);

        // Contains sign in logic
        signinbtn.setOnClickListener(view -> {
            String user = username.getText().toString();
            String pass = password.getText().toString();

            if (user.equals("") || pass.equals("")) {
                Toast.makeText(LoginActivity.this, "Please enter credentials", Toast.LENGTH_SHORT).show();
            } else {
                Boolean result = myDB.checkusernamePassword(user, pass);
                if (result) {
                    Intent intent = new Intent(getApplicationContext(), GridActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Routes users to the registration activity when button is clicked
        createacctbtn.setOnClickListener(view -> {
            Intent int1 = new Intent(getApplicationContext(), RegisterAccountActivity.class);
            startActivity(int1);
        });
    }
}

/* Temp login for ease of use:
*   Username: JoshuaP
*   Password: qwerty
* */